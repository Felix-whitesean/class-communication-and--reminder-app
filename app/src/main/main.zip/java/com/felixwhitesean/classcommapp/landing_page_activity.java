
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		landing_page
	 *	@date 		Monday 01st of July 2024 08:45:20 AM
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package com.felixwhitesean.classcommapp;

    import android.app.Activity;
    import android.os.Bundle;
    import android.view.View;
    import android.widget.ImageView;
    import android.widget.TextView;

    public class landing_page_activity extends Activity {


    private View _bg__landing_page_ek2;
    private View rectangle_3;
    private View rectangle_2;
    private View rectangle_6;
    private ImageView image_10;
    private ImageView image_8;
    private ImageView image_9;
    private ImageView _1_ao_1;
    private ImageView mask_group;
    private ImageView mask_group_ek1;
    private ImageView mask_group_ek2;
    private ImageView _1_ao_1_ek1;
    private ImageView _1_ao_1_ek2;
    private View ellipse_13;
    private View ellipse_14;
    private View ellipse_15;
    private View ellipse_19;
    private ImageView vector;
    private TextView local_colors;
    private ImageView vector_ek1;
    private View ellipse_21;
    private View ellipse_20;
    private View rectangle_4;
    private ImageView rectangle_29;
    private View rectangle_28;
    private TextView get_started;
    private ImageView vector_ek2;
    private View rectangle_1;
    private View rectangle_3_ek1;
    private View home_indicator;
    private View rectangle_17;
    private TextView ultimate_class;

    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.landing_page);


        _bg__landing_page_ek2 = (View) findViewById(R.id._bg__landing_page_ek2);
//        rectangle_3 = (View) findViewById(R.id.rectangle_3);
//        rectangle_2 = (View) findViewById(R.id.rectangle_2);
//        rectangle_6 = (View) findViewById(R.id.rectangle_6);
//        image_10 = (ImageView) findViewById(R.id.image_10);
//        image_8 = (ImageView) findViewById(R.id.image_8);
//        image_9 = (ImageView) findViewById(R.id.image_9);
//        _1_ao_1 = (ImageView) findViewById(R.id._1_ao_1);
//        mask_group = (ImageView) findViewById(R.id.mask_group);
//       a mask_group_ek1 = (ImageView) findViewById(R.id.mask_group_ek1);
//        mask_group_ek2 = (ImageView) findViewById(R.id.mask_group_ek2);
//        _1_ao_1_ek1 = (ImageView) findViewById(R.id._1_ao_1_ek1);
//        _1_ao_1_ek2 = (ImageView) findViewById(R.id._1_ao_1_ek2);
//        ellipse_13 = (View) findViewById(R.id.ellipse_13);
//        ellipse_14 = (View) findViewById(R.id.ellipse_14);
//        ellipse_15 = (View) findViewById(R.id.ellipse_15);
//        ellipse_19 = (View) findViewById(R.id.ellipse_19);
//        vector = (ImageView) findViewById(R.id.vector);
//        local_colors = (TextView) findViewById(R.id.local_colors);
//        vector_ek1 = (ImageView) findViewById(R.id.vector_ek1);
//        ellipse_21 = (View) findViewById(R.id.ellipse_21);
//        ellipse_20 = (View) findViewById(R.id.ellipse_20);
//        rectangle_4 = (View) findViewById(R.id.rectangle_4);
        rectangle_29 = (ImageView) findViewById(R.id.rectangle_29);
        rectangle_28 = (View) findViewById(R.id.rectangle_28);
//        get_started = (TextView) findViewById(R.id.get_started);
//        vector_ek2 = (ImageView) findViewById(R.id.vector_ek2);
        rectangle_1 = (View) findViewById(R.id.rectangle_1);
//        rectangle_3_ek1 = (View) findViewById(R.id.rectangle_3_ek1);
//        home_indicator = (View) findViewById(R.id.home_indicator);
        rectangle_17 = (View) findViewById(R.id.rectangle_17);
//        ultimate_class = (TextView) findViewById(R.id.ultimate_class);


        //custom code goes here

    }
}
	
	